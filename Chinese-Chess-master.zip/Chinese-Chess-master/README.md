# Chinese-Chess
利用神经网络算法和遗传算法作为AI的中国象棋程序
