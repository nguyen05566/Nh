﻿using UnityEngine;
using System.Collections;

public class UBot : UGamer
{
}
