﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 为了网络联机预留的非本地玩家控制器
/// </summary>
public class UPlayerController : UController {

}
