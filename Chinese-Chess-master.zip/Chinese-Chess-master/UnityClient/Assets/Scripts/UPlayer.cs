﻿using UnityEngine;
using System.Collections;

public class UPlayer :UGamer {
    public static UPlayer LocalPlayer;


    //第一层
    //以
    //以整个棋盘为输入，输出选择的棋子
    //以棋子为输入，输出行走策略

    
}
